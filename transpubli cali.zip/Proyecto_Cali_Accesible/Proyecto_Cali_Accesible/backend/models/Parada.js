const mongoose = require('mongoose');

const paradaSchema = new mongoose.Schema({
  nombre: String,
  ubicacion: String,
  descripcion: String,  // ✅ AGREGAR
  accesibilidad: String,
  horarios: String
});

module.exports = mongoose.model('Parada', paradaSchema);
