const express = require('express');
const router = express.Router();
const Parada = require('../models/Parada');

router.post('/', async (req, res) => {
  try {
    const nuevaParada = new Parada({
      nombre: req.body.nombre,
      ubicacion: req.body.ubicacion,
      descripcion: req.body.descripcion,
      accesibilidad: req.body.accesibilidad,
      horarios: req.body.horarios
    });

    await nuevaParada.save();
    res.status(201).json(nuevaParada);
  } catch (error) {
    res.status(400).json({ mensaje: 'Error al crear parada', error });
  }
});

module.exports = router;
