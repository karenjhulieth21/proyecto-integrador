const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
require("dotenv").config();

const app = express();

// Habilitar CORS para evitar errores de conexión desde frontend
app.use(cors());

// Para poder leer JSON en las peticiones
app.use(express.json());

// ====================
// ✅ Conexión a MongoDB
// ====================

const uri = process.env.MONGODB_URI || "mongodb://localhost:27017/cali_accesible";

mongoose
  .connect(uri, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  })
  .then(() => console.log("✅ Conectado a MongoDB"))
  .catch((err) => console.error("❌ Error de conexión:", err));

// ====================
// ✅ Importar rutas
// ====================

const usuarioRoutes = require("./routes/usuarios.routes");
const paradaRoutes = require("./routes/parada.routes");

// ====================
// ✅ Usar rutas
// ====================

app.use("/api/usuarios", usuarioRoutes);
app.use("/api/paradas", paradaRoutes);

// ====================
// ✅ Iniciar servidor
// ====================

const PORT = process.env.PORT || 5001;
app.listen(PORT, () => {
  console.log(`🚀 Servidor backend escuchando en puerto ${PORT}`);
});
